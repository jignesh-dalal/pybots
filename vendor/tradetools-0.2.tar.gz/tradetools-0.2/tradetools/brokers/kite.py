from tradetools.utils import KiteExt
from tradetools.entities import Asset
from typing import List, Dict, Any

class Kite():
    def __init__(self, config=None, user_id=None, access_token=None, debug=False):
        
         # Check if the user provided both config file and keys
        if (access_token is not None or user_id is not None) and config is not None:
            raise Exception(
                "Please provide either a config file or user_id and access_token for Kite. "
                "You have provided both a config file and keys so we don't know which to use."
            )
        
        self.user_id = user_id
        self.access_token = access_token
        self.password = None
        self.totp_key = None

        # Check if the user has provided a config file
        if config is not None:
            # print(config)
            # Check if the user provided all the necessary keys
            if "USER_ID" not in config:
                raise Exception("'USER_ID' not found in Kite config")
            # if "ACCESS_TOKEN" or ("PASSWORD" and "TOTP_KEY") not in config:
            #     raise Exception("'ACCESS_TOKEN' or ('PASSWORD' and 'TOTP_KEY') not found in Kite config")

            # Set the values from the config file
            self.user_id = config["USER_ID"]
            self.access_token = config["ACCESS_TOKEN"]
            self.password = config["PASSWORD"]
            self.totp_key = config["TOTP_KEY"]

        self.api = KiteExt(debug=debug, disable_ssl=True)
        # self.access_token = self.api.create_session(user_id=user_id, password=password, totp_key=totp_key, access_token=access_token)

    def create_session(self):
        self.access_token = self.api.create_session(user_id=self.user_id, password=self.password, totp_key=self.totp_key, access_token=self.access_token)
        # self.nse_instruments = self.instruments()

    def create_asset(
        self,
        symbol: str,
        asset_type: str = "stock",
        exchange: str = None,
        instrument_token = None
    ):
        return Asset(
            symbol=symbol,
            asset_type=asset_type,
            exchange=exchange,
            instrument_token=instrument_token
        )

    def instruments(self, exchange=KiteExt.EXCHANGE_NSE) -> List:
        return self.api.instruments(exchange)
        # return pd.read_csv(inst_csv)
    
    def ltp(self, *assets: Asset) -> Dict[str, Any]:
        exchange_tradingsymbols = tuple(a.exchange_symbol for a in assets)
        ltp_dict = self.api.ltp(exchange_tradingsymbols)
        return ltp_dict
    
    def get_ask_bid(self, *assets: Asset) -> Dict[str, Any]:
        exchange_tradingsymbols = tuple(a.exchange_symbol for a in assets)
        quotes = self.api.quote(exchange_tradingsymbols)
        ask_bid_dict = {key:{'bids': value['depth']['buy'], 'asks': value['depth']['sell']} for (key,value) in quotes.items()}
        return ask_bid_dict
    
    def place_order(
        self, 
        asset: Asset,
        transaction_type, 
        quantity, 
        variety=KiteExt.VARIETY_REGULAR, 
        product=KiteExt.PRODUCT_CNC, 
        order_type=KiteExt.ORDER_TYPE_LIMIT, 
        price=None, 
        validity=None,
        validity_ttl=None,
        disclosed_quantity=None, 
        trigger_price=None, 
        iceberg_legs=None, 
        iceberg_quantity=None, 
        auction_number=None, 
        tag=None) -> str:
       
        if order_type == 'MARKET':
            price = 0
            trigger_price = None

        order_id = self.api.place_order(
            variety, 
            asset.exchange, 
            asset.symbol, 
            transaction_type, 
            quantity, 
            product, 
            order_type, 
            price, 
            validity, 
            validity_ttl, 
            disclosed_quantity, 
            trigger_price, 
            iceberg_legs, 
            iceberg_quantity, 
            auction_number, 
            tag)
        
        return order_id
    
    def order_history(self, order_id: str) -> List:
        response = self.api.order_history(order_id)
        return response
    
    def holdings(self) -> List:
        holdings = self.api.holdings()
        return holdings
    
    def historical_data(self, asset: Asset, from_date, to_date, interval, continuous=False, oi=False):
        pass