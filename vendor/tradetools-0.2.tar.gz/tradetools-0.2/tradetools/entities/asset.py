class Asset:
    symbol: str
    exchange: str = None
    asset_type: str = "stock"
    instrument_token: str = None

    def __init__(
        self,
        symbol: str,
        exchange: str = None,
        asset_type: str = "stock",
        instrument_token = None
    ):
        self.symbol = symbol
        self.exchange = exchange
        self.asset_type = asset_type
        self.instrument_token = instrument_token

    @property
    def exchange_symbol(self):
        return f'{self.exchange}:{self.symbol}'