from setuptools import setup, find_packages

# with open("requirements.txt", "r") as f:
#     REQUIREMENTS = f.read().splitlines()

setup(
    name='tradetools',
    version='0.2',
    description='Trading library for Indian indices',
    author='Jignesh Dalal',
    packages=find_packages(),
    install_requires=[
        "pyotp==2.9.0",
        "kiteconnect==5.0.1",
        "gspread>=6.0.1",
        "pandas>=2.0.0,<=2.0.3",
        "requests",
        "pytz",
    ],
    include_dirs=['tradetools']
)

## https://medium.com/analytics-vidhya/python-code-obfuscation-a2779af857bb
# try:
#     import sourcedefender
# except ModuleNotFoundError:
#     pass
# import os
# from setuptools import setup, find_namespace_packages
# PROJECT = "hello_world"
# def package_pye_files(directory):
#     paths = []
#     for (path, directories, filenames) in os.walk(directory):
#         for filename in filenames:
#             if filename.endswith('.pye'):
#                 paths.append(os.path.join('..', path, filename))
#     return paths
# pye_files = package_pye_files(f"./{PROJECT}")
# PACKAGE_DATA = {
#     PROJECT: ["./resources/*"] + pye_files
# }
# with open("requirements.txt", "r") as f:
#     REQUIREMENTS = f.read().splitlines()
# setup(
#     name=PROJECT,
#     version="0.0.1",
#     description="hello_world",
#     author="None",
#     python_requires='>=3',
#     packages=find_namespace_packages(include=[f"{PROJECT}*"]),
#     package_data=PACKAGE_DATA,
#     include_package_data=True,
#     install_requires=REQUIREMENTS
# )